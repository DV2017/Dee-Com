<?php require_once("../ecom_resources/config.php");?>
<?php include(TEMPLATE_FRONT. DS . "header.php"); ?>

<?php

process_transaction();
      
?>

    <!-- Page Content -->
    <div class="container">

        <h1 class="text-center">Thank you</h1>

    </div><!--Main Content-->

    <hr>

<!-- Footer -->

<?php include(TEMPLATE_FRONT. DS . "footer.php"); ?>